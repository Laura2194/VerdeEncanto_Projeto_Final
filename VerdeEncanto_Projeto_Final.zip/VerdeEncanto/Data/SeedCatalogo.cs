using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;

namespace Esse_deu_certo_MVC_Exemplo.Data;

public static class SeedCatalogo
{
    public static void Inicializar(LojaContext db, IConfiguration configuration)
    {
        var adminEmail = configuration["Admin:Email"];
        var adminSenha = configuration["Admin:Senha"];
        if (!string.IsNullOrWhiteSpace(adminEmail) && !string.IsNullOrWhiteSpace(adminSenha) && !db.Usuarios.Any(u => u.Email == adminEmail))
        {
            var admin = new Usuario { Nome = "Administrador Verde Encanto", Email = adminEmail.Trim(), Tipo = "Admin" };
            admin.Senha = new PasswordHasher<Usuario>().HashPassword(admin, adminSenha);
            db.Usuarios.Add(admin);
            db.SaveChanges();
        }

        var categoriasPadrao = new[] { "Velas e Aromas", "Corpo e Banho", "Cuidados Faciais", "Cabelos e Barba" };
        foreach (var nomeCategoria in categoriasPadrao)
        {
            if (!db.Categorias.Any(c => c.Nome == nomeCategoria))
                db.Categorias.Add(new Categoria { Nome = nomeCategoria });
        }
        db.SaveChanges();

        if (db.Produtos.Any()) return;

        var categorias = db.Categorias.ToDictionary(c => c.Nome, c => c.Id);
        var produtos = new[]
        {
            new Produto { Nome="Velas Aromáticas", Preco=25m, Descricao="Feitas com cera vegetal e fragrâncias envolventes, criam um ambiente acolhedor e relaxante.", ImagemUrl="/images/products/vela.svg", QuantidadeEstoque=30, CategoriaId=categorias["Velas e Aromas"] },
            new Produto { Nome="Perfume Sólido", Preco=35m, Descricao="Perfume em creme prático, delicado e fácil de levar na bolsa.", ImagemUrl="/images/products/perfume.svg", QuantidadeEstoque=30, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Sabonete", Preco=18m, Descricao="Sabonete artesanal com ingredientes selecionados para uma rotina de cuidado suave.", ImagemUrl="/images/products/sabonete.svg", QuantidadeEstoque=40, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Hidratante Labial", Preco=15m, Descricao="Bálsamo nutritivo para ajudar a manter os lábios macios e hidratados.", ImagemUrl="/images/products/labial.svg", QuantidadeEstoque=35, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Óleos Corporais", Preco=45m, Descricao="Óleo corporal para uma massagem relaxante e uma sensação de pele macia.", ImagemUrl="/images/products/oleo.svg", QuantidadeEstoque=20, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Sais de Banho", Preco=30m, Descricao="Uma combinação aromática para transformar o banho em um momento de bem-estar.", ImagemUrl="/images/products/sais.svg", QuantidadeEstoque=25, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Esfoliante Corporal", Preco=40m, Descricao="Esfoliante para renovar a pele e deixar um toque macio e perfumado.", ImagemUrl="/images/products/esfoliante.svg", QuantidadeEstoque=20, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Creme e Manteiga Corporal", Preco=50m, Descricao="Textura rica e cremosa para nutrir a pele e completar seu ritual de autocuidado.", ImagemUrl="/images/products/creme.svg", QuantidadeEstoque=20, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Desodorante Natural", Preco=28m, Descricao="Cuidado diário com fragrância suave e sensação de frescor.", ImagemUrl="/images/products/desodorante.svg", QuantidadeEstoque=30, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Máscara Facial", Preco=22m, Descricao="Máscara facial para uma rotina de cuidado e sensação de pele renovada.", ImagemUrl="/images/products/mascara.svg", QuantidadeEstoque=25, CategoriaId=categorias["Cuidados Faciais"] },
            new Produto { Nome="Shampoo em Barra", Preco=30m, Descricao="Alternativa prática para a rotina capilar, com embalagem reduzida.", ImagemUrl="/images/products/shampoo.svg", QuantidadeEstoque=25, CategoriaId=categorias["Cabelos e Barba"] },
            new Produto { Nome="Tônico Facial", Preco=38m, Descricao="Tônico leve para complementar a rotina diária de cuidados faciais.", ImagemUrl="/images/products/tonico.svg", QuantidadeEstoque=20, CategoriaId=categorias["Cuidados Faciais"] },
            new Produto { Nome="Cera para Cabelo e Barba", Preco=25m, Descricao="Cera modeladora para ajudar a alinhar e modelar os fios.", ImagemUrl="/images/products/cera.svg", QuantidadeEstoque=25, CategoriaId=categorias["Cabelos e Barba"] },
            new Produto { Nome="Tintura Labial", Preco=20m, Descricao="Cor suave e confortável para valorizar os lábios no dia a dia.", ImagemUrl="/images/products/tintura.svg", QuantidadeEstoque=25, CategoriaId=categorias["Corpo e Banho"] },
            new Produto { Nome="Cera de Cabelo em Bastão", Preco=35m, Descricao="Aplicação prática para controlar os fios e finalizar o penteado.", ImagemUrl="/images/products/bastao.svg", QuantidadeEstoque=20, CategoriaId=categorias["Cabelos e Barba"] },
            new Produto { Nome="Aromatizante", Preco=26m, Descricao="Fragrância para perfumar ambientes e criar uma atmosfera acolhedora.", ImagemUrl="/images/products/aromatizante.svg", QuantidadeEstoque=20, CategoriaId=categorias["Velas e Aromas"] }
        };
        db.Produtos.AddRange(produtos);
        db.SaveChanges();
    }
}
