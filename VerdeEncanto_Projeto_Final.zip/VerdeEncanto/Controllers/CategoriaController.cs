﻿using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Esse_deu_certo_MVC_Exemplo.Controllers
{
    public class CategoriaController : Controller
    {
        private readonly LojaContext _db;

        public CategoriaController(LojaContext db)
        {
            _db = db;
        }

        private bool IsAdmin() => HttpContext.Session.GetString("UsuarioTipo") == "Admin";

        public IActionResult Index()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            var categorias = _db.Categorias.ToList();
            return View(categorias);
        }

        [HttpGet] // get request para exibir o formulário
        public IActionResult Cadastrar()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Categoria categoria)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            if (ModelState.IsValid)
            {
                _db.Categorias.Add(categoria);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(categoria);
        }

        [HttpGet]
        public IActionResult Editar(int id)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            var categoria = _db.Categorias.Find(id);
            return View(categoria);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(Categoria categoria)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            if (ModelState.IsValid)
            {
                _db.Categorias.Update(categoria);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(categoria);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Excluir(int id)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Usuario");
            var categoria = _db.Categorias.Find(id);
            if (categoria != null)
            {
                if (_db.Produtos.Any(p => p.CategoriaId == id))
                    TempData["Erro"] = "Não é possível excluir uma categoria que possui produtos cadastrados.";
                else
                {
                    _db.Categorias.Remove(categoria);
                    _db.SaveChanges();
                }
            }
            return RedirectToAction("Index");
        }
    }
}
