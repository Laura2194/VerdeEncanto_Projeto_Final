using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Esse_deu_certo_MVC_Exemplo.Controllers;

public class ProdutoController : Controller
{
    private readonly LojaContext _db;
    public ProdutoController(LojaContext db) => _db = db;

    public IActionResult Index(string? busca, int? categoria, string? ordenacao)
    {
        var produtos = _db.Produtos.Include(p => p.Categoria).AsQueryable();
        if (!string.IsNullOrWhiteSpace(busca))
            produtos = produtos.Where(p => p.Nome.Contains(busca) || p.Descricao.Contains(busca));
        if (categoria.HasValue && categoria.Value > 0)
            produtos = produtos.Where(p => p.CategoriaId == categoria.Value);

        produtos = ordenacao switch
        {
            "preco_asc" => produtos.OrderBy(p => p.Preco),
            "preco_desc" => produtos.OrderByDescending(p => p.Preco),
            "novo" => produtos.OrderByDescending(p => p.DataCadastro),
            "vendidos" => produtos.OrderByDescending(p => p.QuantidadeVendida),
            _ => produtos.OrderBy(p => p.Nome)
        };
        ViewBag.Categorias = new SelectList(_db.Categorias.OrderBy(c => c.Nome), "Id", "Nome", categoria);
        ViewBag.Busca = busca;
        ViewBag.CategoriaSelecionada = categoria;
        ViewBag.Ordenacao = ordenacao;
        return View(produtos.ToList());
    }

    public IActionResult Detalhes(int id)
    {
        var produto = _db.Produtos.Include(p => p.Categoria).FirstOrDefault(p => p.Id == id);
        return produto == null ? NotFound() : View(produto);
    }

    [HttpGet]
    public IActionResult Create()
    {
        if (HttpContext.Session.GetString("UsuarioTipo") != "Admin") return RedirectToAction("Login", "Usuario");
        ViewBag.Categorias = new SelectList(_db.Categorias.OrderBy(c => c.Nome), "Id", "Nome");
        return View("~/Views/Admin/CadastrarProduto.cshtml");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult CadastrarProduto(Produto produto)
    {
        if (HttpContext.Session.GetString("UsuarioTipo") != "Admin") return RedirectToAction("Login", "Usuario");
        if (produto.CategoriaId <= 0 || !_db.Categorias.Any(c => c.Id == produto.CategoriaId))
            ModelState.AddModelError(nameof(produto.CategoriaId), "Selecione uma categoria válida.");
        if (produto.Preco < 0) ModelState.AddModelError(nameof(produto.Preco), "O preço não pode ser negativo.");
        if (produto.QuantidadeEstoque < 0) ModelState.AddModelError(nameof(produto.QuantidadeEstoque), "O estoque não pode ser negativo.");
        if (ModelState.IsValid)
        {
            produto.DataCadastro = DateTime.Now;
            _db.Produtos.Add(produto);
            _db.SaveChanges();
            return RedirectToAction("Produtos", "Admin");
        }
        ViewBag.Categorias = new SelectList(_db.Categorias.OrderBy(c => c.Nome), "Id", "Nome", produto.CategoriaId);
        return View("~/Views/Admin/CadastrarProduto.cshtml", produto);
    }
}
