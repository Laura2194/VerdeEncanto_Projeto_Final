using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Helpers;
using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Esse_deu_certo_MVC_Exemplo.Controllers;

public class CarrinhoController : Controller
{
    private readonly LojaContext _db;
    private const string SessaoCarrinho = "Carrinho";
    public CarrinhoController(LojaContext db) => _db = db;

    public IActionResult Index()
    {
        var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new();
        ViewBag.Total = carrinho.Sum(i => i.Preco * i.Quantidade);
        return View(carrinho);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Adicionar(int produtoId, int quantidade = 1)
    {
        var produto = _db.Produtos.FirstOrDefault(p => p.Id == produtoId);
        if (produto == null) return NotFound();
        if (quantidade < 1) quantidade = 1;
        if (produto.QuantidadeEstoque <= 0)
        {
            TempData["Mensagem"] = "Este produto está sem estoque no momento.";
            return RedirectToAction("Index", "Produto");
        }

        var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new();
        var item = carrinho.FirstOrDefault(i => i.ProdutoId == produtoId);
        var quantidadeFinal = (item?.Quantidade ?? 0) + quantidade;
        if (quantidadeFinal > produto.QuantidadeEstoque)
        {
            TempData["Mensagem"] = $"Temos apenas {produto.QuantidadeEstoque} unidade(s) de {produto.Nome} em estoque.";
            return RedirectToAction("Index");
        }
        if (item == null)
            carrinho.Add(new ItemCarrinho { ProdutoId = produto.Id, Produto = produto, Quantidade = quantidade, Preco = produto.Preco, NomeProduto = produto.Nome, ImagemUrl = produto.ImagemUrl });
        else
        {
            item.Quantidade = quantidadeFinal;
            item.Preco = produto.Preco;
            item.NomeProduto = produto.Nome;
            item.ImagemUrl = produto.ImagemUrl;
        }
        HttpContext.Session.SetObject(SessaoCarrinho, carrinho);
        TempData["Sucesso"] = "Produto adicionado ao carrinho.";
        return RedirectToAction("Index");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Atualizar(int produtoId, int quantidade)
    {
        var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new();
        var item = carrinho.FirstOrDefault(i => i.ProdutoId == produtoId);
        var produto = _db.Produtos.FirstOrDefault(p => p.Id == produtoId);
        if (item != null && produto != null)
        {
            if (quantidade <= 0) carrinho.Remove(item);
            else if (quantidade <= produto.QuantidadeEstoque) item.Quantidade = quantidade;
            else TempData["Mensagem"] = $"Estoque disponível para este produto: {produto.QuantidadeEstoque}.";
            HttpContext.Session.SetObject(SessaoCarrinho, carrinho);
        }
        return RedirectToAction("Index");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Remover(int id)
    {
        var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new();
        carrinho.RemoveAll(i => i.ProdutoId == id);
        HttpContext.Session.SetObject(SessaoCarrinho, carrinho);
        return RedirectToAction("Index");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Limpar()
    {
        HttpContext.Session.Remove(SessaoCarrinho);
        return RedirectToAction("Index");
    }
}
