using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Helpers;
using Esse_deu_certo_MVC_Exemplo.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Mail;

namespace Esse_deu_certo_MVC_Exemplo.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly LojaContext _db;
        private readonly IConfiguration _configuration;
        private const string SessaoCarrinho = "Carrinho";
        private const string SessaoUsuario = "UsuarioLogado";

        public CheckoutController(LojaContext db, IConfiguration configuration)
        {
            _db = db;
            _configuration = configuration;
        }

        // View do carrinho (mostra itens e botão de confirmar)
        public IActionResult Index()
        {
            var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new List<ItemCarrinho>();
            ViewBag.Total = carrinho.Sum(i => i.Preco * i.Quantidade);
            return View(carrinho);
        }

        // Confirma a compra e salva no banco
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ConfirmarCompra(string metodoPagamento = "Cartão de Crédito")
        {
            var carrinho = HttpContext.Session.GetObject<List<ItemCarrinho>>(SessaoCarrinho) ?? new List<ItemCarrinho>();

            if (!carrinho.Any())
                return RedirectToAction("Index", "Carrinho");

            // Recupera usuário logado da sessão
            var usuarioJson = HttpContext.Session.GetString(SessaoUsuario);
            if (string.IsNullOrEmpty(usuarioJson))
            {
                TempData["Mensagem"] = "Faça login para confirmar a compra.";
                return RedirectToAction("Login", "Usuario");
            }

            var usuarioSess = JsonConvert.DeserializeObject<Usuario>(usuarioJson);
            if (usuarioSess == null)
            {
                TempData["Mensagem"] = "Usuário inválido. Faça login novamente.";
                return RedirectToAction("Login", "Usuario");
            }

            var usuarioDb = _db.Usuarios.FirstOrDefault(u => u.Id == usuarioSess.Id);
            if (usuarioDb == null)
            {
                TempData["Mensagem"] = "Usuário não encontrado. Faça login novamente.";
                return RedirectToAction("Login", "Usuario");
            }

            // Revalida estoque e preço no servidor antes de registrar a compra.
            foreach (var item in carrinho)
            {
                var produtoAtual = _db.Produtos.FirstOrDefault(p => p.Id == item.ProdutoId);
                if (produtoAtual == null || item.Quantidade < 1 || produtoAtual.QuantidadeEstoque < item.Quantidade)
                {
                    TempData["Mensagem"] = $"Estoque insuficiente para {item.NomeProduto}. Revise seu carrinho.";
                    return RedirectToAction("Index", "Carrinho");
                }
                item.Preco = produtoAtual.Preco;
                item.NomeProduto = produtoAtual.Nome;
                item.ImagemUrl = produtoAtual.ImagemUrl;
            }

            // Cria nova venda
            var venda = new Venda
            {
                ValorTotal = carrinho.Sum(i => i.Preco * i.Quantidade),
                Itens = carrinho.Select(i => new ItemCarrinho
                {
                    ProdutoId = i.ProdutoId,
                    Quantidade = i.Quantidade,
                    Preco = i.Preco,
                    NomeProduto = i.NomeProduto,
                    ImagemUrl = i.ImagemUrl,
                    UsuarioId = usuarioDb.Id
                }).ToList(),
                DataVenda = DateTime.Now
            };

            _db.Vendas.Add(venda);

            // Atualiza estoque
            foreach (var item in venda.Itens)
            {
                var produto = _db.Produtos.FirstOrDefault(p => p.Id == item.ProdutoId);
                if (produto != null)
                {
                    produto.QuantidadeVendida += item.Quantidade;
                    produto.QuantidadeEstoque -= item.Quantidade;
                }
            }

            _db.SaveChanges();

            // Envio do e-mail com nota fiscal fictícia
            try
            {
                var pdf = GerarNotaFiscalPdf(venda, carrinho, metodoPagamento);
                EnviarEmailComAnexo(
                    destinatario: usuarioDb.Email,
                    itens: carrinho,
                    valorTotal: venda.ValorTotal,
                    metodoPagamento: metodoPagamento,
                    pdfBytes: pdf
                );
            }
            catch (Exception ex)
            {
                TempData["ErroEmail"] = "Erro ao enviar e-mail: " + ex.Message;
                Console.WriteLine(ex);
            }

            // Limpa carrinho e redireciona
            HttpContext.Session.Remove(SessaoCarrinho);
            return RedirectToAction("Confirmacao");
        }

        // Geração do PDF da nota fiscal fictícia
        private byte[] GerarNotaFiscalPdf(Venda venda, List<ItemCarrinho> itens, string metodoPagamento)
        {
            using (var ms = new MemoryStream())
            {
                var doc = new Document(PageSize.A4, 40, 40, 40, 40);
                PdfWriter.GetInstance(doc, ms);
                doc.Open();

                string logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "minha_loja_logo.png");
                if (System.IO.File.Exists(logoPath))
                {
                    var logo = iTextSharp.text.Image.GetInstance(logoPath);
                    logo.Alignment = Element.ALIGN_CENTER;
                    logo.ScaleToFit(120f, 120f);
                    doc.Add(logo);
                }

                doc.Add(new Paragraph(" "));
                var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLUE);
                var normal = FontFactory.GetFont(FontFactory.HELVETICA, 12);
                var bold = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12);

                Paragraph titulo = new Paragraph("Nota Fiscal (Fictícia)", titleFont);
                titulo.Alignment = Element.ALIGN_CENTER;
                doc.Add(titulo);

                doc.Add(new Paragraph($"Data da Compra: {venda.DataVenda:dd/MM/yyyy HH:mm}", normal));
                doc.Add(new Paragraph($"Forma de Pagamento: {metodoPagamento}", normal));
                doc.Add(new Paragraph(" "));

                PdfPTable table = new PdfPTable(4) { WidthPercentage = 100 };
                table.SetWidths(new float[] { 50f, 15f, 10f, 25f });

                BaseColor headerColor = new BaseColor(240, 240, 240);
                AddCell(table, "Produto", bold, headerColor);
                AddCell(table, "Preço", bold, headerColor);
                AddCell(table, "Qtd", bold, headerColor);
                AddCell(table, "Total", bold, headerColor);

                foreach (var it in itens)
                {
                    AddCell(table, it.NomeProduto ?? "(sem nome)", normal);
                    AddCell(table, $"R$ {it.Preco:F2}", normal);
                    AddCell(table, it.Quantidade.ToString(), normal);
                    AddCell(table, $"R$ {(it.Preco * it.Quantidade):F2}", normal);
                }

                doc.Add(table);
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph($"Valor Total: R$ {venda.ValorTotal:F2}", bold));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph("Obrigado por comprar com a Verde Encanto!", normal));

                doc.Close();
                return ms.ToArray();
            }
        }

        private void AddCell(PdfPTable table, string text, Font font, BaseColor bgColor = null)
        {
            var cell = new PdfPCell(new Phrase(text, font))
            {
                Padding = 5,
                BackgroundColor = bgColor
            };
            table.AddCell(cell);
        }

        // Envio de e-mail com PDF em anexo
        private void EnviarEmailComAnexo(string destinatario, List<ItemCarrinho> itens, decimal valorTotal, string metodoPagamento, byte[] pdfBytes)
        {
            // O envio é opcional. Configure Email:Remetente e Email:SenhaAplicativo em segredo local.
            var remetente = _configuration["Email:Remetente"];
            var senha = _configuration["Email:SenhaAplicativo"];
            if (string.IsNullOrWhiteSpace(remetente) || string.IsNullOrWhiteSpace(senha))
                throw new InvalidOperationException("O envio de e-mail não está configurado. A compra foi registrada normalmente.");

            var servidor = _configuration["Email:ServidorSmtp"] ?? "smtp.gmail.com";
            var porta = int.TryParse(_configuration["Email:PortaSmtp"], out var portaConfigurada) ? portaConfigurada : 587;
            var assunto = "Confirmação de Pedido - Verde Encanto";
            var corpo = $"<h2>Compra confirmada - Verde Encanto</h2><p>Seu pedido foi registrado com sucesso.</p><p>Pagamento: {System.Net.WebUtility.HtmlEncode(metodoPagamento)}</p><p>Total: R$ {valorTotal:F2}</p><p>O comprovante segue em anexo.</p>";
            using var message = new MailMessage();
            message.From = new MailAddress(remetente, "Verde Encanto");
            message.To.Add(destinatario);
            message.Subject = assunto;
            message.Body = corpo;
            message.IsBodyHtml = true;
            if (pdfBytes is { Length: > 0 })
                message.Attachments.Add(new Attachment(new MemoryStream(pdfBytes), "Comprovante_VerdeEncanto.pdf", "application/pdf"));
            using var smtp = new SmtpClient(servidor, porta) { Credentials = new NetworkCredential(remetente, senha), EnableSsl = true };
            smtp.Send(message);
        }

        // Tela de confirmação
        public IActionResult Confirmacao()
        {
            if (TempData["ErroEmail"] != null)
                ViewBag.ErroEmail = TempData["ErroEmail"].ToString();

            return View();
        }
    }
}
