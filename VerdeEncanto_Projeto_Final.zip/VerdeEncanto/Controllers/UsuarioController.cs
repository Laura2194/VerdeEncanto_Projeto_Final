using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Esse_deu_certo_MVC_Exemplo.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly LojaContext _db;
        private readonly PasswordHasher<Usuario> _passwordHasher = new();

        public UsuarioController(LojaContext db)
        {
            _db = db;
        }

        public IActionResult Login() => View(); // Ação para exibir o formulário de login

        [HttpPost]
        [ValidateAntiForgeryToken] // Ação para processar o login
        public IActionResult Login(string email, string senha)
        {
            var usuario = _db.Usuarios.FirstOrDefault(u => u.Email == email);
            var senhaValida = false;
            if (usuario != null)
            {
                if (usuario.Senha.StartsWith("AQAAAA", StringComparison.Ordinal))
                    senhaValida = _passwordHasher.VerifyHashedPassword(usuario, usuario.Senha, senha ?? string.Empty) != PasswordVerificationResult.Failed;
                else if (usuario.Senha == senha)
                {
                    // Compatibilidade: converte senha antiga em texto puro para hash no primeiro login.
                    usuario.Senha = _passwordHasher.HashPassword(usuario, senha ?? string.Empty);
                    _db.SaveChanges();
                    senhaValida = true;
                }
            }
            if (usuario != null && senhaValida)
            {
                // Cria sessão (valores individuais, mantidos para compatibilidade)
                HttpContext.Session.SetString("UsuarioNome", usuario.Nome);
                HttpContext.Session.SetString("UsuarioEmail", usuario.Email);
                HttpContext.Session.SetString("UsuarioTipo", usuario.Tipo);

                // Grava também um objeto JSON contendo o Id — usado pelo CheckoutController
                var usuarioSessao = new Usuario
                {
                    Id = usuario.Id,
                    Nome = usuario.Nome,
                    Email = usuario.Email,
                    Tipo = usuario.Tipo
                };
                HttpContext.Session.SetString("UsuarioLogado", JsonConvert.SerializeObject(usuarioSessao));

                if (usuario.Tipo == "Admin")
                    return RedirectToAction("Dashboard", "Admin");
                else
                    return RedirectToAction("Index", "Produto");
            }

            ViewBag.Mensagem = "Usuário ou senha incorretos!";
            return View();

        }

        // Ação para logout = encerrar sessão
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); // Encerra sessão
            return RedirectToAction("Login");
        }

        public IActionResult Cadastrar() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Usuario usuario)
        {
            if (_db.Usuarios.Any(u => u.Email == usuario.Email))
                ModelState.AddModelError(nameof(usuario.Email), "Este e-mail já possui cadastro.");
            if (ModelState.IsValid)
            {
                usuario.Tipo = "Cliente";
                usuario.Senha = _passwordHasher.HashPassword(usuario, usuario.Senha);
                _db.Usuarios.Add(usuario);
                _db.SaveChanges();
                return RedirectToAction("Login");
            }
            ViewBag.Mensagem = "Dados inválidos!";
            return View(usuario);
        }

        // Histórico de pedidos do usuário autenticado.
        public IActionResult Pedidos()
        {
            var usuarioId = HttpContext.Session.GetString("UsuarioLogado");
            if (string.IsNullOrWhiteSpace(usuarioId))
                return RedirectToAction("Login");

            var usuario = JsonConvert.DeserializeObject<Usuario>(usuarioId);
            if (usuario == null) return RedirectToAction("Login");

            var pedidos = _db.Vendas
                .Include(v => v.Itens)
                .Where(v => v.Itens.Any(i => i.UsuarioId == usuario.Id))
                .OrderByDescending(v => v.DataVenda)
                .ToList();
            return View(pedidos);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SalvarPerfil(string nome, string email)
        {
            var emailAtual = HttpContext.Session.GetString("UsuarioEmail");
            if (string.IsNullOrWhiteSpace(emailAtual)) return RedirectToAction("Login");
            nome = (nome ?? string.Empty).Trim();
            email = (email ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(email) || !new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email))
            {
                TempData["Mensagem"] = "Informe um nome e um e-mail válidos.";
                return RedirectToAction("Perfil");
            }
            if (_db.Usuarios.Any(u => u.Email == email && u.Email != emailAtual))
            {
                TempData["Mensagem"] = "Este e-mail já está cadastrado em outra conta.";
                return RedirectToAction("Perfil");
            }
            var usuario = _db.Usuarios.FirstOrDefault(u => u.Email == emailAtual);
            if (usuario == null) return RedirectToAction("Login");
            usuario.Nome = nome; usuario.Email = email; _db.SaveChanges();
            HttpContext.Session.SetString("UsuarioNome", nome); HttpContext.Session.SetString("UsuarioEmail", email);
            var usuarioJson = HttpContext.Session.GetString("UsuarioLogado");
            if (!string.IsNullOrWhiteSpace(usuarioJson)) { var sessao = JsonConvert.DeserializeObject<Usuario>(usuarioJson); if (sessao != null) { sessao.Nome = nome; sessao.Email = email; HttpContext.Session.SetString("UsuarioLogado", JsonConvert.SerializeObject(sessao)); } }
            TempData["Sucesso"] = "Perfil atualizado com sucesso.";
            return RedirectToAction("Perfil");
        }

        // Ação para exibir perfil do usuário
        public IActionResult Perfil()
        {
            var usuarioNome = HttpContext.Session.GetString("UsuarioNome");
            var usuarioTipo = HttpContext.Session.GetString("UsuarioTipo");
            var usuarioEmail = HttpContext.Session.GetString("UsuarioEmail"); // opcional, se você salvou no login

            if (usuarioNome == null)
            {
                // Se não houver nome de usuário na sessão, redireciona para login
                return RedirectToAction("Login", "Usuario");
            }

            // Monta um objeto Usuario apenas com os dados necessários
            var usuario = new Usuario
            {
                Nome = usuarioNome,
                Email = usuarioEmail,
                Tipo = usuarioTipo
            };

            return View(usuario);
        }

    }
}