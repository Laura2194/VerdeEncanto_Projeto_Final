using System.Diagnostics;
using Esse_deu_certo_MVC_Exemplo.Data;
using Esse_deu_certo_MVC_Exemplo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Esse_deu_certo_MVC_Exemplo.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly LojaContext _db;
    public HomeController(ILogger<HomeController> logger, LojaContext db) { _logger = logger; _db = db; }

    public IActionResult Index()
    {
        var todos = _db.Produtos.Include(p => p.Categoria).ToList();
        var destaques = new[] { "Tintura Labial", "Velas Aromáticas", "Tônico Facial" };
        var produtos = destaques.Select(nome => todos.FirstOrDefault(p => p.Nome == nome)).Where(p => p != null).Cast<Produto>().ToList();
        if (produtos.Count < 3)
            produtos.AddRange(todos.Where(p => produtos.All(d => d.Id != p.Id)).OrderByDescending(p => p.QuantidadeVendida).ThenBy(p => p.Nome).Take(3 - produtos.Count));
        return View(produtos);
    }
    public IActionResult Privacy() => View();
    public IActionResult Sobre() => View();
    public IActionResult Feedback() => View();
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
