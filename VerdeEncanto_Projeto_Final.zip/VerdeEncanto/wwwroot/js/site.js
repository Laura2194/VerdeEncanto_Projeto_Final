(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  document.addEventListener('DOMContentLoaded', () => {
    // Story carousel: arrows, dots, keyboard and swipe.
    const slides = $$('.story-slide');
    const dots = $$('.story-dot');
    let current = 0;
    const showSlide = (index) => {
      if (!slides.length) return;
      current = (index + slides.length) % slides.length;
      slides.forEach((slide, i) => { slide.classList.toggle('is-active', i === current); slide.setAttribute('aria-hidden', String(i !== current)); });
      dots.forEach((dot, i) => { dot.classList.toggle('is-active', i === current); dot.setAttribute('aria-pressed', String(i === current)); });
    };
    $('.story-prev')?.addEventListener('click', () => showSlide(current - 1));
    $('.story-next')?.addEventListener('click', () => showSlide(current + 1));
    dots.forEach(dot => dot.addEventListener('click', () => showSlide(Number(dot.dataset.go))));
    const carousel = $('.story-carousel'); let touchStart = 0;
    carousel?.addEventListener('touchstart', e => { touchStart = e.changedTouches[0].clientX; }, {passive:true});
    carousel?.addEventListener('touchend', e => { const delta = e.changedTouches[0].clientX - touchStart; if (Math.abs(delta) > 45) showSlide(current + (delta < 0 ? 1 : -1)); }, {passive:true});
    carousel?.addEventListener('keydown', e => { if (e.key === 'ArrowRight') showSlide(current+1); if (e.key === 'ArrowLeft') showSlide(current-1); });
    showSlide(0);

    // Search dropdown in the header.
    const searchToggle = $('#searchToggle'); const searchForm = $('#headerSearch');
    searchToggle?.addEventListener('click', () => { const opening = searchForm.hidden; searchForm.hidden = !opening; searchToggle.setAttribute('aria-expanded', String(opening)); if (opening) $('#headerSearchInput')?.focus(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && searchForm && !searchForm.hidden) { searchForm.hidden = true; searchToggle?.focus(); } });

    // Theme toggle with persistence.
    const savedTheme = localStorage.getItem('ve-theme'); if (savedTheme === 'dark') document.body.classList.add('theme-dark');
    $('#themeToggle')?.addEventListener('click', () => { document.body.classList.toggle('theme-dark'); localStorage.setItem('ve-theme', document.body.classList.contains('theme-dark') ? 'dark' : 'light'); });

    // Favorites stored locally for this browser.
    const favorites = new Set(JSON.parse(localStorage.getItem('ve-favorites') || '[]').map(String));
    const saveFavorites = () => localStorage.setItem('ve-favorites', JSON.stringify([...favorites]));
    $$('[data-favorite]').forEach(button => {
      const id = String(button.dataset.favorite); const active = favorites.has(id);
      button.classList.toggle('is-favorite', active); button.textContent = active ? '♥' : '♡'; button.setAttribute('aria-pressed', String(active));
      button.addEventListener('click', () => { if (favorites.has(id)) favorites.delete(id); else favorites.add(id); saveFavorites(); const now = favorites.has(id); button.classList.toggle('is-favorite', now); button.textContent = now ? '♥' : '♡'; button.setAttribute('aria-pressed', String(now)); button.setAttribute('aria-label', now ? 'Remover dos favoritos' : 'Adicionar aos favoritos'); });
    });

    // Micro-interaction only; do not override disabled/submitting buttons.
    $$('.btn, .icon-button').forEach(button => button.addEventListener('pointerdown', () => { if (!button.disabled) button.classList.add('is-pressed'); }));
    document.addEventListener('pointerup', () => $$('.is-pressed').forEach(el => el.classList.remove('is-pressed')));

  });
})();
